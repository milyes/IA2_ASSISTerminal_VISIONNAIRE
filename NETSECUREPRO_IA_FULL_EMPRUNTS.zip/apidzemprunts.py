from fastapi import FastAPI, Request, Form
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
import sqlite3

app = FastAPI()
templates = Jinja2Templates(directory="templates")

def init_db():
    conn = sqlite3.connect("emprunts.db")
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS emprunts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nom TEXT,
        objet TEXT,
        date TEXT
    )''')
    conn.commit()
    conn.close()

@app.on_event("startup")
def startup():
    init_db()

@app.get("/", response_class=HTMLResponse)
def index(request: Request):
    conn = sqlite3.connect("emprunts.db")
    c = conn.cursor()
    c.execute("SELECT * FROM emprunts")
    rows = c.fetchall()
    conn.close()
    return templates.TemplateResponse("index.html", {"request": request, "emprunts": rows})

@app.post("/ajouter")
def ajouter_emprunt(nom: str = Form(...), objet: str = Form(...), date: str = Form(...)):
    conn = sqlite3.connect("emprunts.db")
    c = conn.cursor()
    c.execute("INSERT INTO emprunts (nom, objet, date) VALUES (?, ?, ?)", (nom, objet, date))
    conn.commit()
    conn.close()
    return {"message": "Emprunt ajouté avec succès"}
