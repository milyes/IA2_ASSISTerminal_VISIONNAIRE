# FastAPI Emprunts IA

Lancez avec :

```bash
uvicorn apidzemprunts:app --reload --host 0.0.0.0 --port 8000
```