echo "[Scanner IA] Lancement du scan réseau..."
ifconfig
echo "[Scanner IA] Localisation actuelle :"
termux-location
