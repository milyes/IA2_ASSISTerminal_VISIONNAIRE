echo "[Vision IA] Capture d'image en cours..."
termux-camera-photo -c 0 ia2_capture.jpg && echo "[✔️] Image capturée : ia2_capture.jpg"
