# Traitement_IA.py

import nltk
nltk.download('punkt')
from nltk.tokenize import word_tokenize
from transformers import pipeline

# Initialisation du modèle d’analyse de sentiment
model_sentiment = pipeline("sentiment-analysis", model="distilbert-base-uncased-finetuned-sst-2-english")

# Initialisation des modèles de traduction (FR -> EN ici)
model_traduction = pipeline("translation_fr_to_en", model="Helsinki-NLP/opus-mt-fr-en")

# Initialisation du modèle de correction grammaticale
model_correction = pipeline("text2text-generation", model="t5-base")

# Fonction d’analyse de texte
def analyser_texte(texte):
    tokens = word_tokenize(texte)
    sentiment = model_sentiment(texte)
    info = {
        "tokens": tokens,
        "sentiment": sentiment[0]["label"],
        "confiance": round(sentiment[0]["score"], 2)
    }
    return info

# Fonction de traduction
def traduire_texte(texte):
    traduction = model_traduction(texte, max_length=200)
    return traduction[0]["translation_text"]

# Fonction de correction
def corriger_orthographe(texte):
    prompt = f"Correct this: {texte}"
    correction = model_correction(prompt, max_length=64)
    return correction[0]["generated_text"]

# Exemple d'utilisation
if __name__ == "__main__":
    texte = "Je suis très satisfait de ce produit !"

    print("🔍 Analyse de sentiment :")
    resultat = analyser_texte(texte)
    print(resultat)

    print("\n🌍 Traduction en anglais :")
    traduction = traduire_texte(texte)
    print(traduction)

    print("\n📝 Correction grammaticale :")
    correction = corriger_orthographe("He go to the market every days.")
    print(correction)
