import time
print("[IA2_ENGINE] Moteur IA2 lancé avec succès.")
time.sleep(1)
print("[IA2_ENGINE] Prêt à analyser les flux ou commandes IA.")
