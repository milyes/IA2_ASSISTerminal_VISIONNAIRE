#!/bin/bash
mkdir -p logs
echo "[+] Lancement de l'analyse de sécurité IA2 ASSISTerminal..." > logs/security_report.log
echo "Heure: $(date)" >> logs/security_report.log

echo "--- PORTS OUVERTS ---" >> logs/security_report.log
netstat -tuln >> logs/security_report.log 2>/dev/null

echo "--- UTILISATEURS CONNECTÉS ---" >> logs/security_report.log
command -v who >/dev/null && who >> logs/security_report.log || echo "Commande 'who' non disponible" >> logs/security_report.log

echo "--- DERNIÈRES CONNEXIONS ---" >> logs/security_report.log
command -v last >/dev/null && last -a | head -n 10 >> logs/security_report.log || echo "Commande 'last' non disponible" >> logs/security_report.log

echo "--- PROCESSUS SYSTÈME ---" >> logs/security_report.log
ps aux --sort=-%mem | head -n 10 >> logs/security_report.log

echo "[+] Analyse terminée. Rapport enregistré dans logs/security_report.log"
python3 ai_anomaly_detector.py
