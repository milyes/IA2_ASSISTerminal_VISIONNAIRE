#!/bin/bash
echo "[IA2_ASSISTerminal_VISIONNAIRE] Initialisation..."
source venv/bin/activate
python ia_core.py
