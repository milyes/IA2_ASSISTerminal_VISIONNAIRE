🔐 API IA NeuroSync accessible publiquement via Cloudflare Tunnel

🌍 URL :
https://evaluation-essentials-challenging-loaded.trycloudflare.com

📱 QR Code inclus : QR_NeuroSync_Cloudflare_LIVE.png

🧠 Script de démarrage automatique :
bash start_ia_api.sh

Auteur : Zoubirou Mohammed Ilyes
