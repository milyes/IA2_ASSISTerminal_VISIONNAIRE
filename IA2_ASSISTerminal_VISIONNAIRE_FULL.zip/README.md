# IA2_ASSISTerminal_VISIONNAIRE

Un module IA avancé intégré à la plateforme NetSecurePro.  
Fonctionnalités :  
- Analyse de texte (sentiment, tokens)  
- Traduction automatique EN -> FR  
- Correction orthographique intelligente  
- Interface CLI interactive  

Auteur : Zoubirou Mohammed Ilyes  
Lien : https://github.com/milyes/IA2_ASSISTerminal_VISIONNAIRE.git  
ORCID : https://orcid.org/0009-0007-7571-3178
