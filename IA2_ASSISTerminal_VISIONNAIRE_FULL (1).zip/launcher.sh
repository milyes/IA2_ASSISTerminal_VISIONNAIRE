#!/bin/bash
echo "🔐 IA2 ASSISTerminal VISIONNAIRE – Centre de Sécurité"
echo "1. Lancer l’analyse sécurité complète"
echo "2. Lire le rapport"
echo "3. Lancer IA uniquement"
echo "4. Quitter"
read -p "Choix : " choix

case $choix in
  1) ./run_security_check.sh ;;
  2) cat logs/security_report.log ;;
  3) python3 ai_anomaly_detector.py ;;
  4) echo "Sortie..." ;;
  *) echo "Option invalide." ;;
esac
