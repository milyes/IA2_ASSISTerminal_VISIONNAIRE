#!/data/data/com.termux/files/usr/bin/bash
uvicorn apidzemprunts:app --reload --host 0.0.0.0 --port 8000